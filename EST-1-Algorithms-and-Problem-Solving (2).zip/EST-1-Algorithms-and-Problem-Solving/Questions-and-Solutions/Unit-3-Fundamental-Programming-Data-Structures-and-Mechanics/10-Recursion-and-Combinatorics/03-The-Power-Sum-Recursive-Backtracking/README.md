# The Power Sum (Subset Combinations via Recursion)

## 1. Problem Title
- **Title:** The Power Sum (Subset Combinations via Recursion)
- **Problem ID:** `U3-10-03`
- **Topic Section:** 10. Recursion & Combinatorics
- **Difficulty:** Medium
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [The Power Sum](https://www.hackerrank.com/challenges/the-power-sum/problem)

## 3. Problem Statement Summary
Find the number of ways that a given integer `X` can be expressed as the sum of the `N`-th powers of unique, natural numbers (`1^N, 2^N, 3^N, ...`).

## 4. Objective
Apply recursive include/exclude subset combination exploration (`countWays(X - cur^N, N, cur + 1) + countWays(X, N, cur + 1)`).

## 5. Algorithm
1. Define recursive function `solve(remaining, N, base)` starting at `base = 1`.
2. Compute `p = pow(base, N)`. If `p > remaining`, return `0`; if `p == remaining`, return `1`.
3. Return `solve(remaining - p, N, base + 1) + solve(remaining, N, base + 1)`.

## 6. Step-by-Step Procedure
1. **Step 1 (Base Case Evaluation):** Check if `base^N` equals or exceeds `remaining`.
2. **Step 2 (Include/Exclude Branching):** Recursively sum ways that include `base^N` and ways that skip `base^N`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-10-03
// Title        : The Power Sum
// HackerRank   : https://www.hackerrank.com/challenges/the-power-sum/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/the-power-sum/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
100
2
```

### Sample Output
```text
3
```

## 9. Time Complexity
- **Time Complexity:** `O(2^(X^(1/N)))`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(X^(1/N)) recursion stack`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers **The Power Sum** and **Subset combinations** subtopics in Unit 3 Section 10.
