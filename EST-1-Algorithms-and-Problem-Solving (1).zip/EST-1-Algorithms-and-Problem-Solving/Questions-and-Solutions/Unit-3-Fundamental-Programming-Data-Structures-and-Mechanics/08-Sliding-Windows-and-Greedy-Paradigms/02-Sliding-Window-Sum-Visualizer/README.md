# Sliding Window Sum (Console Simulation)

## 1. Problem Title
- **Title:** Sliding Window Sum (Console Simulation)
- **Problem ID:** `U3-08-02`
- **Topic Section:** 08. Sliding Windows & Greedy Paradigms
- **Difficulty:** Easy
- **Language:** C (Uploaded Visualizer)
- **Status:** Completed (Uploaded C Visualizer)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Uploaded Console Visualizer)

## 3. Problem Statement Summary
Interactive C console visualizer that slides a window of size `k = 3` across a 6-element array `{1, 2, 3, 4, 5, 6}`, highlighting the active window elements and computing each window sum.

## 4. Objective
Visualize contiguous subarray window boundaries `[i, i + k - 1]` and window sum progression.

## 5. Algorithm
1. Initialize the 6-element array `a[6] = {1, 2, 3, 4, 5, 6}`.
2. Slide the left boundary `i` from `0` to `3` (`n - k`).
3. In each frame, highlight elements with index `j` in `[i, i + 2]` in yellow (`14`) and outside elements in cyan (`11`).
4. Accumulate `sum` over `j = i` to `i + 2`, print `Window Sum = sum`, and pause `1000 ms`.

## 6. Step-by-Step Procedure
1. **Step 1 (Array Setup):** Define `a[6] = {1, 2, 3, 4, 5, 6}` and console handle `h`.
2. **Step 2 (Window Shift Loop):** Advance starting index `i` from `0` to `3`.
3. **Step 3 (Boundary Highlighting & Summation):** Color indices `j >= i && j < i + 3`, sum the 3 active elements, and render the sum.

## 7. C++ Source Code (`solution.c`)
```c
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

int main()
{
    int a[6] = {1, 2, 3, 4, 5, 6};
    int i, j, sum;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    for(i = 0; i <= 3; i++)
    {
        system("cls");

        printf("\n\n       SLIDING WINDOW\n\n");

        for(j = 0; j < 6; j++)
        {
            if(j >= i && j < i + 3)
                SetConsoleTextAttribute(h, 14);
            else
                SetConsoleTextAttribute(h, 11);

            printf("      [ %d ]", a[j]);
        }

        sum = 0;

        for(j = i; j < i + 3; j++)
            sum = sum + a[j];

        SetConsoleTextAttribute(h, 10);

        printf("\n\n       Window Sum = %d\n", sum);

        Sleep(1000);
    }

    SetConsoleTextAttribute(h, 7);

    printf("\n       Sliding Completed!\n");

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
[Embedded array: {1, 2, 3, 4, 5, 6}, Window size K = 3]
```

### Sample Output
```text
Window Sum = 6
Window Sum = 9
Window Sum = 12
Window Sum = 15
Sliding Completed!
```

## 9. Time Complexity
- **Time Complexity:** `O(N * K)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
This is your original uploaded C sliding window visualizer preserved verbatim. It animates how a fixed-length window of size `3` shifts one index to the right on each step across `{1, 2, 3, 4, 5, 6}`.
