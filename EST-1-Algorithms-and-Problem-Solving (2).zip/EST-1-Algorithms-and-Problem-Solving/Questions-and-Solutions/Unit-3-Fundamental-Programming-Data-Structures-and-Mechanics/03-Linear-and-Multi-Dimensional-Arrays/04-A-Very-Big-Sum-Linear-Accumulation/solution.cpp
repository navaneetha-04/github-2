// ============================================================================
// Problem ID   : U3-03-04
// Title        : A Very Big Sum
// HackerRank   : https://www.hackerrank.com/challenges/a-very-big-sum/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/a-very-big-sum/problem

    return 0;
}
