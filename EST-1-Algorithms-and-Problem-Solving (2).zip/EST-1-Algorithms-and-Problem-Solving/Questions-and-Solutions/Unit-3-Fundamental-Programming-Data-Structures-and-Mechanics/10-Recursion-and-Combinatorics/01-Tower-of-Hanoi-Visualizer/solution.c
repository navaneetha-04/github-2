#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

int rods[3][10];
int count[3] = {0, 0, 0};
int n = 3;

void display()
{
    int i, j, r, disk;
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    system("cls");

    printf("\n\n       TOWER OF HANOI\n\n");

    for(i = n-1; i >= 0; i--)
    {
        for(r = 0; r < 3; r++)
        {
            if(count[r] > i)
            {
                disk = rods[r][i];

                SetConsoleTextAttribute(h, 9 + disk % 6);

                for(j = 0; j < disk * 2 - 1; j++)
                    printf("=");

                SetConsoleTextAttribute(h, 7);
            }
            else
            {
                printf("|");
            }

            printf("\t\t");
        }

        printf("\n");
    }

    printf("   A\t\tB\t\tC\n");

    Sleep(800);
}

void moveDisk(int s, int d)
{
    int disk;

    disk = rods[s][count[s]-1];
    count[s]--;

    rods[d][count[d]] = disk;
    count[d]++;

    display();
}

void tower(int n, int s, int a, int d)
{
    if(n == 1)
    {
        moveDisk(s, d);
        return;
    }

    tower(n-1, s, d, a);

    moveDisk(s, d);

    tower(n-1, a, s, d);
}

int main()
{
    int i;

    for(i = n; i >= 1; i--)
    {
        rods[0][count[0]] = i;
        count[0]++;
    }

    display();

    tower(n, 0, 1, 2);

    printf("\n   All disks moved successfully!\n");

    return 0;
}
