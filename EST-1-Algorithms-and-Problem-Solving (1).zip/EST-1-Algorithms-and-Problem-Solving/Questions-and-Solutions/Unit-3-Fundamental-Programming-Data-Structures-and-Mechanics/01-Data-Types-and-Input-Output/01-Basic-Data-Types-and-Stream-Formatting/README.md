# Basic Data Types & Stream Formatting

## 1. Problem Title
- **Title:** Basic Data Types & Stream Formatting
- **Problem ID:** `U3-01-01`
- **Topic Section:** 01. Data Types & Input/Output
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Basic Data Types](https://www.hackerrank.com/challenges/c-tutorial-basic-data-types/problem)

## 3. Problem Statement Summary
Read five space-separated values representing standard C++ primitive types (`int`, `long`, `char`, `float`, and `double`) from standard input and print each value on a new line with exact decimal precision (`3` decimal places for `float` and `9` decimal places for `double`).

## 4. Objective
Understand C++ primitive data type bit-widths, prevent precision loss across 32-bit and 64-bit types, apply stream formatting (`std::fixed` and `std::setprecision`), and configure fast standard I/O.

## 5. Algorithm
1. Disable synchronization between C and C++ standard streams (`std::ios_base::sync_with_stdio(false)`) and untie `std::cin` from `std::cout` for fast I/O.
2. Declare five typed variables: `int i`, `long l`, `char c`, `float f`, and `double d`.
3. Read all five tokens sequentially from `std::cin`.
4. Output `i`, `l`, and `c` on separate lines.
5. Apply `std::fixed` and `std::setprecision(3)` to print `f`, then `std::setprecision(9)` to print `d`.

## 6. Step-by-Step Procedure
1. **Step 1 (Stream Optimization):** Call `std::ios_base::sync_with_stdio(false);` and `std::cin.tie(NULL);` at the start of `main()` so `std::cin` and `std::cout` operate without `stdio` buffer synchronization overhead.
2. **Step 2 (Variable Allocation):** Allocate variables matching the required bit-width ranges (`int` for 32-bit signed integers, `long` for 64-bit integers, `char` for 1-byte ASCII characters, `float` for single-precision IEEE-754 floats, and `double` for double-precision floats).
3. **Step 3 (Input Extraction):** Use `std::cin >> i >> l >> c >> f >> d` inside a condition check to safely read the whitespace-delimited tokens.
4. **Step 4 (Formatted Output):** Print the integer and character variables directly followed by `"\n"`. Use `<iomanip>` manipulators `std::fixed` and `std::setprecision(3)` for `f`, and `std::setprecision(9)` for `d` so trailing zeros and exact decimal places are preserved.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <iomanip>

int main() {
    // Fast I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int i;
    long l;
    char c;
    float f;
    double d;

    if (std::cin >> i >> l >> c >> f >> d) {
        std::cout << i << "\n";
        std::cout << l << "\n";
        std::cout << c << "\n";
        std::cout << std::fixed << std::setprecision(3) << f << "\n";
        std::cout << std::fixed << std::setprecision(9) << d << "\n";
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
3 12345678912345 a 334.23 14049.30493
```

### Sample Output
```text
3
12345678912345
a
334.230
14049.304930000
```

## 9. Time Complexity
- **Time Complexity:** `O(1)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
In C++, printing a `float` or `double` with `std::cout` normally uses default general formatting (up to 6 significant digits total), which truncates or switches to scientific notation for large numbers. By combining `std::fixed` with `std::setprecision(k)` from `<iomanip>`, we instruct the output stream to format numbers with exactly `k` digits after the decimal point. In addition, `std::ios_base::sync_with_stdio(false)` and `std::cin.tie(NULL)` speed up standard input/output so it runs as fast as C's `scanf`/`printf` while preserving C++ type safety.
