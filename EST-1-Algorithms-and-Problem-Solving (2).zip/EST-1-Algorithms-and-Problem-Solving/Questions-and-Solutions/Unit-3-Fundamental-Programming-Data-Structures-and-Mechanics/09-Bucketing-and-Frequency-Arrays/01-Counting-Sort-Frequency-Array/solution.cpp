#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        std::vector<int> freq(100, 0);
        for (int i = 0; i < n; ++i) {
            int val;
            std::cin >> val;
            if (val >= 0 && val < 100) {
                freq[val]++;
            }
        }

        for (int i = 0; i < 100; ++i) {
            std::cout << freq[i] << (i == 99 ? "" : " ");
        }
        std::cout << "\n";
    }

    return 0;
}
