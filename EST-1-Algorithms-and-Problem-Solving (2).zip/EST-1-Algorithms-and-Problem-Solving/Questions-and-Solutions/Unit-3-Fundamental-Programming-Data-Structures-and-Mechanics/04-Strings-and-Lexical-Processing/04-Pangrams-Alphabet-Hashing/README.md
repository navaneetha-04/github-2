# Pangrams (Alphabet Hashing)

## 1. Problem Title
- **Title:** Pangrams (Alphabet Hashing)
- **Problem ID:** `U3-04-04`
- **Topic Section:** 04. Strings & Lexical Processing
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Pangrams](https://www.hackerrank.com/challenges/pangrams/problem)

## 3. Problem Statement Summary
Given a sentence `s`, determine whether it is a pangram (contains every letter of the English alphabet `a-z` at least once, case-insensitively).

## 4. Objective
Apply direct character-to-index hashing (`std::tolower(c) - 'a'`) into a 26-bucket boolean/frequency table.

## 5. Algorithm
1. Read the full line `s` using `std::getline(std::cin, s)`.
2. Allocate a boolean array `seen[26]` initialized to `false`.
3. For each character `c` in `s`, if `std::isalpha(c)`, mark `seen[std::tolower(c) - 'a'] = true`.
4. If all 26 entries in `seen` are `true`, print `pangram`; otherwise print `not pangram`.

## 6. Step-by-Step Procedure
1. **Step 1 (Full-Line Input):** Use `std::getline` because sentences contain spaces.
2. **Step 2 (26-Bucket Hash):** Map each alphabetic character to `0..25` via `tolower(c) - 'a'`.
3. **Step 3 (Completeness Verification):** Check if all 26 buckets were visited.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-04-04
// Title        : Pangrams
// HackerRank   : https://www.hackerrank.com/challenges/pangrams/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/pangrams/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
We promptly judged antique ivory buckles for the next prize
```

### Sample Output
```text
pangram
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1) (26 boolean buckets)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Alphabet hashing** subtopic in Unit 3 Section 4.
