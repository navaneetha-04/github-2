# Day 25: Running Time and Complexity (O(sqrt N) Prime Verification)

## 1. Problem Title
- **Title:** Day 25: Running Time and Complexity (O(sqrt N) Prime Verification)
- **Problem ID:** `U3-11-03`
- **Topic Section:** 11. Complexity & Sorting Analysis
- **Difficulty:** Medium
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Day 25: Running Time and Complexity](https://www.hackerrank.com/challenges/30-running-time-and-complexity/problem)

## 3. Problem Statement Summary
Given `T` integers (each up to `2 * 10^9`), determine for each integer whether it is `Prime` or `Not prime` in `O(sqrt(N))` time.

## 4. Objective
Reduce primality testing complexity from naive `O(N)` trial division to `O(sqrt(N))` by testing divisors up to `d * d <= n`.

## 5. Algorithm
1. If `n < 2`, return `Not prime`; if `n == 2`, return `Prime`; if `n % 2 == 0`, return `Not prime`.
2. Test odd divisors `d = 3, 5, 7, ...` while `d * d <= n`: if `n % d == 0`, return `Not prime`.
3. If no divisor is found, return `Prime`.

## 6. Step-by-Step Procedure
1. **Step 1 (Edge Cases):** Handle `n <= 1` and even numbers immediately.
2. **Step 2 (Square-Root Trial Division):** Loop `long long d = 3; d * d <= n; d += 2`.
3. **Step 3 (Output):** Print `Prime` or `Not prime`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-11-03
// Title        : Day 25: Running Time and Complexity
// HackerRank   : https://www.hackerrank.com/challenges/30-running-time-and-complexity/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/30-running-time-and-complexity/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
3
12
5
7
```

### Sample Output
```text
Not prime
Prime
Prime
```

## 9. Time Complexity
- **Time Complexity:** `O(T * sqrt(N))`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Prime verification O(sqrt N)** and **Running Time and Complexity** subtopics in Unit 3 Section 11.
