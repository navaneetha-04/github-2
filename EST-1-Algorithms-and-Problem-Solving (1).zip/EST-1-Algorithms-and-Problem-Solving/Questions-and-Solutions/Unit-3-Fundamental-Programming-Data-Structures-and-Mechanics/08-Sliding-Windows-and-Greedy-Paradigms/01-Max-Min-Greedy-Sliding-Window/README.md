# Max Min (Minimum Unfairness via Greedy Sliding Window)

## 1. Problem Title
- **Title:** Max Min (Minimum Unfairness via Greedy Sliding Window)
- **Problem ID:** `U3-08-01`
- **Topic Section:** 08. Sliding Windows & Greedy Paradigms
- **Difficulty:** Medium
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Max Min](https://www.hackerrank.com/challenges/angry-children/problem)

## 3. Problem Statement Summary
Given a list of `n` integers and a subset size `k`, choose `k` elements from the list such that the unfairness `max(subset) - min(subset)` is minimized.

## 4. Objective
Combine sorting (`std::sort`) with a fixed-size `k` sliding window to find the tightest cluster of `k` elements in `O(N log N)` time.

## 5. Algorithm
1. Read `n`, `k`, and the `n` array elements into `std::vector<long long> arr(n)`.
2. Sort `arr` in non-decreasing order (`std::sort(arr.begin(), arr.end())`).
3. Initialize `min_unfairness = 1e18`.
4. Slide a window of length `k` from `i = 0` to `n - k`, computing `current_unfairness = arr[i + k - 1] - arr[i]`.
5. Update `min_unfairness = std::min(min_unfairness, current_unfairness)` and output the result.

## 6. Step-by-Step Procedure
1. **Step 1 (Input):** Read `n`, `k`, and the array of 64-bit integers.
2. **Step 2 (Greedy Ordering):** Sort the array ascending. In a sorted array, any subset of `k` elements that minimizes `max - min` must be a contiguous subarray of length `k`.
3. **Step 3 (Window Sweep):** For each contiguous window `arr[i .. i+k-1]`, its minimum is `arr[i]` and its maximum is `arr[i + k - 1]`. Take the minimum difference across all `n - k + 1` windows.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n, k;
    if (std::cin >> n >> k) {
        std::vector<long long> arr(n);
        for (int i = 0; i < n; ++i) {
            std::cin >> arr[i];
        }

        std::sort(arr.begin(), arr.end());

        long long min_unfairness = 1e18;
        for (int i = 0; i <= n - k; ++i) {
            long long current_unfairness = arr[i + k - 1] - arr[i];
            min_unfairness = std::min(min_unfairness, current_unfairness);
        }

        std::cout << min_unfairness << "\n";
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
7
3
10
100
300
200
1000
20
30
```

### Sample Output
```text
20
```

## 9. Time Complexity
- **Time Complexity:** `O(N log N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
Checking all `nCk` subsets of size `k` is exponential and infeasible. However, once the array is sorted in ascending order, choosing non-contiguous elements only widens the gap between the smallest and largest chosen elements. Thus, the optimal `k` elements must sit next to each other in the sorted array, reducing the problem to a simple `O(N)` sliding window pass of width `k`.
