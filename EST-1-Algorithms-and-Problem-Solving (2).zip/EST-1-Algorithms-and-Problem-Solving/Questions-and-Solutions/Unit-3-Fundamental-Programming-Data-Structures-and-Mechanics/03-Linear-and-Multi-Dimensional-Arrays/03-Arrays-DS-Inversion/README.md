# Arrays - DS (Array Inversion)

## 1. Problem Title
- **Title:** Arrays - DS (Array Inversion)
- **Problem ID:** `U3-03-03`
- **Topic Section:** 03. Linear & Multi-Dimensional Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Arrays - DS](https://www.hackerrank.com/challenges/arrays-ds/problem)

## 3. Problem Statement Summary
Given an array `A` of `N` integers, reverse the order of elements in the array and print the inverted sequence.

## 4. Objective
Master two-pointer in-place array inversion (`std::swap(a[l], a[r])`) and reverse index traversal.

## 5. Algorithm
1. Read integer `N` and the `N` elements of array `A`.
2. Initialize two pointers `left = 0` and `right = N - 1`.
3. While `left < right`, swap `A[left]` and `A[right]`, then increment `left` and decrement `right`.
4. Print the inverted array elements separated by spaces.

## 6. Step-by-Step Procedure
1. **Step 1 (Input):** Read array length `N` and populate `std::vector<int> a(N)`.
2. **Step 2 (Two-Pointer Swap):** Swap symmetric elements `a[i]` and `a[N - 1 - i]` for `0 <= i < N / 2`.
3. **Step 3 (Output):** Print the reversed sequence.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-03-03
// Title        : Arrays - DS (Array Inversion)
// HackerRank   : https://www.hackerrank.com/challenges/arrays-ds/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/arrays-ds/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
4
1 4 3 2
```

### Sample Output
```text
2 3 4 1
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1) auxiliary (in-place)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Array inversion** subtopic in Unit 3 Section 3.
