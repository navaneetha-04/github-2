# Permutations and Combinations (nPr & nCr Evaluator)

## 1. Problem Title
- **Title:** Permutations and Combinations (nPr & nCr Evaluator)
- **Problem ID:** `U4-04-01`
- **Topic Section:** 04. Permutations & Combinations
- **Difficulty:** Easy
- **Language:** C (Uploaded Visualizer)
- **Status:** Completed (Uploaded C Visualizer)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Uploaded Console Program)

## 3. Problem Statement Summary
Interactive C program that reads `n` and `r`, validates `0 <= r <= n <= 20` (the 64-bit signed factorial limit), and computes both `nPr = n! / (n - r)!` and `nCr = n! / (r! * (n - r)!)`.

## 4. Objective
Compute exact permutations and combinations using 64-bit `long long` factorials while enforcing `n <= 20` overflow bounds.

## 5. Algorithm
1. Read `n` and `r` from standard input.
2. Validate that `0 <= r <= n <= 20` (since `21! > 2^63 - 1` overflows a 64-bit signed `long long`).
3. Compute `factorial(k)` iteratively in `O(k)` time.
4. Evaluate `permutation = factorial(n) / factorial(n - r)` and `combination = factorial(n) / (factorial(r) * factorial(n - r))`.
5. Display the results with console color formatting.

## 6. Step-by-Step Procedure
1. **Step 1 (Input & Overflow Guard):** Read `n` and `r` and reject inputs outside `0 <= r <= n <= 20`.
2. **Step 2 (Iterative Factorial):** Compute `1 * 2 * ... * n` in a `long long` variable.
3. **Step 3 (Formula Evaluation):** Apply the algebraic definitions of `nPr` and `nCr` and print both results.

## 7. C++ Source Code (`solution.c`)
```c
#include <stdio.h>
#include <windows.h>

long long factorial(int n)
{
    long long fact = 1;

    for (int i = 1; i <= n; i++)
        fact = fact * i;

    return fact;
}

int main()
{
    int n, r;
    long long permutation, combination;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    printf("Enter n: ");
    scanf("%d", &n);

    printf("Enter r: ");
    scanf("%d", &r);

    if (n < 0 || r < 0 || r > n || n > 20)
    {
        SetConsoleTextAttribute(h, 12);
        printf("\nInvalid input!\n");
        return 0;
    }

    permutation = factorial(n) / factorial(n - r);

    combination = factorial(n) /
                  (factorial(r) * factorial(n - r));

    SetConsoleTextAttribute(h, 14);
    printf("\n===== PERMUTATION AND COMBINATION =====\n");

    SetConsoleTextAttribute(h, 10);
    printf("\nPermutation (nPr) = %lld", permutation);

    SetConsoleTextAttribute(h, 11);
    printf("\nCombination (nCr) = %lld\n", combination);

    SetConsoleTextAttribute(h, 7);

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
Enter n: 5
Enter r: 2
```

### Sample Output
```text
Permutation (nPr) = 20
Combination (nCr) = 10
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
This is your original uploaded C program preserved verbatim. Note how the check `n > 20` guards against 64-bit integer overflow (`20! = 2,432,902,008,176,640,000`, which is the largest factorial that fits inside a signed 64-bit `long long`).
