# Sherlock and Permutations (Grid Lattice Paths & Modular Inverse Factorials)

## 1. Problem Title
- **Title:** Sherlock and Permutations (Grid Lattice Paths & Modular Inverse Factorials)
- **Problem ID:** `U4-04-03`
- **Topic Section:** 04. Permutations & Combinations
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Sherlock and Permutations](https://www.hackerrank.com/challenges/sherlock-and-permutations/problem)

## 3. Problem Statement Summary
Given `N` zeros (`0`) and `M` ones (`1`), find how many unique permutations of the binary string start with `1`, modulo `10^9 + 7`.

## 4. Objective
Fix the leading `1` and count arrangements of the remaining `N` zeros and `M - 1` ones (equivalent to lattice paths from `(0, 0)` to `(N, M - 1)`): `C(N + M - 1, N) % (10^9 + 7)` using modular inverse factorials.

## 5. Algorithm
1. Fix one `'1'` at index `0`, leaving `N` zeros and `M - 1` ones.
2. Compute `(N + M - 1)! * (N!)^(-1) * ((M - 1)!)^(-1) % 1000000007` using pre-computed factorials and Fermat's Little Theorem modular inverses.

## 6. Step-by-Step Procedure
1. **Step 1 (Combinatorial Reduction):** Reduce to `C(N + M - 1, N)`.
2. **Step 2 (Modular Factorial Division):** Multiply `(N + M - 1)!` by the modular inverses of `N!` and `(M - 1)!` modulo `10^9 + 7`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U4-04-03
// Title        : Sherlock and Permutations
// HackerRank   : https://www.hackerrank.com/challenges/sherlock-and-permutations/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/sherlock-and-permutations/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
1 1
2 3
```

### Sample Output
```text
1
6
```

## 9. Time Complexity
- **Time Complexity:** `O(N + M + log(MOD))`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Grid lattice paths** and **Modular inverse factorials** subtopics in Units 4 & 5 Section 4.
