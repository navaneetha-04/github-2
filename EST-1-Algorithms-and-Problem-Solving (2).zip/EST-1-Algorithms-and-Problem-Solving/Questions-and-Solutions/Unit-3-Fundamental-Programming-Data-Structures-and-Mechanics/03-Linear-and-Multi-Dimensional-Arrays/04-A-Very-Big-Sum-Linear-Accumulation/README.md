# A Very Big Sum (64-Bit Linear Accumulation)

## 1. Problem Title
- **Title:** A Very Big Sum (64-Bit Linear Accumulation)
- **Problem ID:** `U3-03-04`
- **Topic Section:** 03. Linear & Multi-Dimensional Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [A Very Big Sum](https://www.hackerrank.com/challenges/a-very-big-sum/problem)

## 3. Problem Statement Summary
Calculate and print the sum of elements in an array where individual integers can be up to `10^10`, requiring 64-bit integer accumulation (`long long`).

## 4. Objective
Apply linear accumulation while preventing 32-bit signed integer overflow (`2^31 - 1`).

## 5. Algorithm
1. Read `N`, the number of elements.
2. Initialize a 64-bit accumulator `long long total_sum = 0`.
3. Loop `N` times, reading each 64-bit integer `x` and adding `total_sum += x`.
4. Output `total_sum`.

## 6. Step-by-Step Procedure
1. **Step 1 (Accumulator Selection):** Declare `long long sum = 0;` so sums exceeding `2,147,483,647` do not overflow.
2. **Step 2 (Linear Pass):** Read each element in a single `O(N)` loop and accumulate.
3. **Step 3 (Output):** Print the 64-bit total.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-03-04
// Title        : A Very Big Sum
// HackerRank   : https://www.hackerrank.com/challenges/a-very-big-sum/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/a-very-big-sum/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5
1000000001 1000000002 1000000003 1000000004 1000000005
```

### Sample Output
```text
5000000015
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Linear accumulation** subtopic in Unit 3 Section 3.
