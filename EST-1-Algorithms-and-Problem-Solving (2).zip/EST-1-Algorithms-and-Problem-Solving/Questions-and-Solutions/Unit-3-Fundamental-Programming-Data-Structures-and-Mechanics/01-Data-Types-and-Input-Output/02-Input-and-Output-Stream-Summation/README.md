# Input and Output (Stream Extraction & Type Safety)

## 1. Problem Title
- **Title:** Input and Output (Stream Extraction & Type Safety)
- **Problem ID:** `U3-01-02`
- **Topic Section:** 01. Data Types & Input/Output
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Input and Output](https://www.hackerrank.com/challenges/cpp-input-and-output/problem)

## 3. Problem Statement Summary
Read three space-separated integers from standard input (`stdin`) and print their arithmetic sum to standard output (`stdout`).

## 4. Objective
Practice type-safe token extraction using `std::cin` and formatted output using `std::cout`.

## 5. Algorithm
1. Configure fast standard I/O stream settings.
2. Declare three integer variables `a`, `b`, and `c`.
3. Extract `a`, `b`, and `c` from `std::cin`.
4. Compute `a + b + c` and write the result to `std::cout` followed by a newline.

## 6. Step-by-Step Procedure
1. **Step 1 (Setup):** Include `<iostream>` and initialize `main()`.
2. **Step 2 (Read Tokens):** Use the extraction operator `>>` to read three space-separated integers.
3. **Step 3 (Compute & Print):** Add the three integers and output their sum using the insertion operator `<<`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-01-02
// Title        : Input and Output
// HackerRank   : https://www.hackerrank.com/challenges/cpp-input-and-output/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/cpp-input-and-output/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
1 2 7
```

### Sample Output
```text
10
```

## 9. Time Complexity
- **Time Complexity:** `O(1)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
This problem is marked as **Pending** because it was not part of your uploaded C++ submissions. To complete it, read three integers `a`, `b`, and `c` via `std::cin >> a >> b >> c` and print `a + b + c`.
