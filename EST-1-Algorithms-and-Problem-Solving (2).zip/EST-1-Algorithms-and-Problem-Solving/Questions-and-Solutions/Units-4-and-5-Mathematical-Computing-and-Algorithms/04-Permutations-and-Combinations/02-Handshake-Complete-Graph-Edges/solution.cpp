#include <iostream>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int t;
    if (std::cin >> t) {
        while (t--) {
            long long n;
            std::cin >> n;
            long long handshakes = (n * (n - 1)) / 2;
            std::cout << handshakes << "\n";
        }
    }

    return 0;
}
