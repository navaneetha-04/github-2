#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n, k;
    if (std::cin >> n >> k) {
        std::vector<long long> arr(n);
        for (int i = 0; i < n; ++i) {
            std::cin >> arr[i];
        }

        std::sort(arr.begin(), arr.end());

        long long min_unfairness = 1e18;
        for (int i = 0; i <= n - k; ++i) {
            long long current_unfairness = arr[i + k - 1] - arr[i];
            min_unfairness = std::min(min_unfairness, current_unfairness);
        }

        std::cout << min_unfairness << "\n";
    }

    return 0;
}
