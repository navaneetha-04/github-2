# Sherlock and Array (Equilibrium Index via Prefix Sums)

## 1. Problem Title
- **Title:** Sherlock and Array (Equilibrium Index via Prefix Sums)
- **Problem ID:** `U3-07-02`
- **Topic Section:** 07. Pre-computation & Range Techniques
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Sherlock and Array](https://www.hackerrank.com/challenges/sherlock-and-array/problem)

## 3. Problem Statement Summary
Given an array of integers, determine whether there exists an equilibrium index `i` such that the sum of all elements strictly to the left of `i` equals the sum of all elements strictly to the right of `i`.

## 4. Objective
Find an array equilibrium point in `O(N)` time and `O(1)` auxiliary space using total sum pre-computation (`right_sum = total_sum - left_sum - arr[i]`).

## 5. Algorithm
1. Compute the total sum `total` of all elements in the array.
2. Initialize `left_sum = 0`.
3. Iterate through each element `x` in the array: if `left_sum == total - left_sum - x`, return `YES`; otherwise add `left_sum += x`.
4. If the loop finishes without a match, return `NO`.

## 6. Step-by-Step Procedure
1. **Step 1 (Pre-compute Total):** Sum the array in `O(N)`.
2. **Step 2 (Pivot Sweep):** For each index `i`, compare `left_sum` against `right_sum = total - left_sum - arr[i]`.
3. **Step 3 (Output):** Print `YES` if an equilibrium index exists, or `NO` otherwise.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-07-02
// Title        : Sherlock and Array
// HackerRank   : https://www.hackerrank.com/challenges/sherlock-and-array/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/sherlock-and-array/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
3
1 2 3
4
1 2 3 3
```

### Sample Output
```text
NO
YES
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N) to store array (O(1) extra space)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Equilibrium index using prefix sums** subtopic in Unit 3 Section 7.
