#include <iostream>
#include <vector>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        static const std::string words[] = {
            "zero", "one", "two", "three", "four",
            "five", "six", "seven", "eight", "nine"
        };

        if (n >= 1 && n <= 9) {
            std::cout << words[n] << "\n";
        } else {
            std::cout << "Greater than 9\n";
        }
    }

    return 0;
}
