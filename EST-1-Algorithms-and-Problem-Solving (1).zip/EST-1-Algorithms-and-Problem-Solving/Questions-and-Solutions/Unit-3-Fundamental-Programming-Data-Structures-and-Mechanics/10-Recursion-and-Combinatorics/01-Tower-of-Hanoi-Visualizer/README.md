# Tower of Hanoi (Visual Recursive Simulation)

## 1. Problem Title
- **Title:** Tower of Hanoi (Visual Recursive Simulation)
- **Problem ID:** `U3-10-01`
- **Topic Section:** 10. Recursion & Combinatorics
- **Difficulty:** Medium
- **Language:** C (Uploaded Visualizer)
- **Status:** Completed (Uploaded C Visualizer)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Uploaded Console Visualizer)

## 3. Problem Statement Summary
Solve the 3-peg Tower of Hanoi problem recursively for `n = 3` disks and render each disk transfer across rods `A`, `B`, and `C` in the Windows console.

## 4. Objective
Understand recursive state decomposition (`T(n) = 2T(n-1) + 1`) and call-stack execution trees.

## 5. Algorithm
1. Initialize rod `A` (`rods[0]`) with `n = 3` disks stacked in decreasing order of size (`3, 2, 1`).
2. Define `tower(n, s, a, d)` to move `n` disks from source rod `s` to destination rod `d` using auxiliary rod `a`.
3. Base case (`n == 1`): transfer top disk from `s` to `d` and render the rods via `display()`.
4. Recursive step: call `tower(n - 1, s, d, a)`, move the largest disk from `s` to `d`, and call `tower(n - 1, a, s, d)`.

## 6. Step-by-Step Procedure
1. **Step 1 (Initial State):** Populate `rods[0]` with disks `n` down to `1` and render the starting configuration.
2. **Step 2 (Recursive Subproblem 1):** Move the top `n - 1` disks from Source (`s`) to Auxiliary (`a`).
3. **Step 3 (Base Move):** Move disk `n` from Source (`s`) to Destination (`d`) and update the visual display.
4. **Step 4 (Recursive Subproblem 2):** Move the `n - 1` disks from Auxiliary (`a`) to Destination (`d`).

## 7. C++ Source Code (`solution.c`)
```c
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

int rods[3][10];
int count[3] = {0, 0, 0};
int n = 3;

void display()
{
    int i, j, r, disk;
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    system("cls");

    printf("\n\n       TOWER OF HANOI\n\n");

    for(i = n-1; i >= 0; i--)
    {
        for(r = 0; r < 3; r++)
        {
            if(count[r] > i)
            {
                disk = rods[r][i];

                SetConsoleTextAttribute(h, 9 + disk % 6);

                for(j = 0; j < disk * 2 - 1; j++)
                    printf("=");

                SetConsoleTextAttribute(h, 7);
            }
            else
            {
                printf("|");
            }

            printf("\t\t");
        }

        printf("\n");
    }

    printf("   A\t\tB\t\tC\n");

    Sleep(800);
}

void moveDisk(int s, int d)
{
    int disk;

    disk = rods[s][count[s]-1];
    count[s]--;

    rods[d][count[d]] = disk;
    count[d]++;

    display();
}

void tower(int n, int s, int a, int d)
{
    if(n == 1)
    {
        moveDisk(s, d);
        return;
    }

    tower(n-1, s, d, a);

    moveDisk(s, d);

    tower(n-1, a, s, d);
}

int main()
{
    int i;

    for(i = n; i >= 1; i--)
    {
        rods[0][count[0]] = i;
        count[0]++;
    }

    display();

    tower(n, 0, 1, 2);

    printf("\n   All disks moved successfully!\n");

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
n = 3 (Embedded 3-disk configuration on Peg A)
```

### Sample Output
```text
7 animated disk transfers moving all 3 disks from Peg A to Peg C
All disks moved successfully!
```

## 9. Time Complexity
- **Time Complexity:** `O(2^N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N) recursion stack depth`

## 11. Explanation of the Program
This is your original uploaded C Tower of Hanoi visualizer preserved verbatim. Moving `n` disks requires `2^n - 1` moves (`7` moves for `n = 3`), providing a clear visual trace of how recursive calls push and pop frames on the call stack.
