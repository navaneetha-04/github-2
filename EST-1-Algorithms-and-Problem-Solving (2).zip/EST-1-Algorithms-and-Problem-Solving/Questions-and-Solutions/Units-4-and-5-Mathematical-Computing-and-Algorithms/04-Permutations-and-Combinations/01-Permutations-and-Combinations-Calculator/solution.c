#include <stdio.h>
#include <windows.h>

long long factorial(int n)
{
    long long fact = 1;

    for (int i = 1; i <= n; i++)
        fact = fact * i;

    return fact;
}

int main()
{
    int n, r;
    long long permutation, combination;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    printf("Enter n: ");
    scanf("%d", &n);

    printf("Enter r: ");
    scanf("%d", &r);

    if (n < 0 || r < 0 || r > n || n > 20)
    {
        SetConsoleTextAttribute(h, 12);
        printf("\nInvalid input!\n");
        return 0;
    }

    permutation = factorial(n) / factorial(n - r);

    combination = factorial(n) /
                  (factorial(r) * factorial(n - r));

    SetConsoleTextAttribute(h, 14);
    printf("\n===== PERMUTATION AND COMBINATION =====\n");

    SetConsoleTextAttribute(h, 10);
    printf("\nPermutation (nPr) = %lld", permutation);

    SetConsoleTextAttribute(h, 11);
    printf("\nCombination (nCr) = %lld\n", combination);

    SetConsoleTextAttribute(h, 7);

    return 0;
}
