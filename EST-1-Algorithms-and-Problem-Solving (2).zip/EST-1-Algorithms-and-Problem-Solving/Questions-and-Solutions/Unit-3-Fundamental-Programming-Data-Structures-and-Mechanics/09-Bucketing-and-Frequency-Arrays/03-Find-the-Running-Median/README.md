# Find the Running Median (Dynamic Median Tracking)

## 1. Problem Title
- **Title:** Find the Running Median (Dynamic Median Tracking)
- **Problem ID:** `U3-09-03`
- **Topic Section:** 09. Bucketing & Frequency Arrays
- **Difficulty:** Hard
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Find the Running Median](https://www.hackerrank.com/challenges/find-the-running-median/problem)

## 3. Problem Statement Summary
Given a stream of `n` integers arriving one by one, insert each integer into the running set and print the updated median scaled to 1 decimal place after each insertion.

## 4. Objective
Track the running median dynamically using two balanced heaps (a max-heap for the lower half and a min-heap for the upper half) or bucketed order statistics.

## 5. Algorithm
1. Maintain a max-heap `low` (elements `<= median`) and a min-heap `high` (elements `>= median`).
2. Insert each new integer and rebalance so `|low.size() - high.size()| <= 1`.
3. If total elements are odd, the median is the top of the larger heap; if even, the median is `(low.top() + high.top()) / 2.0`.

## 6. Step-by-Step Procedure
1. **Step 1 (Heap Partitioning):** Partition stream elements into lower and upper halves.
2. **Step 2 (Height Balancing):** Keep heap sizes within 1 of each other.
3. **Step 3 (Median Formatting):** Print the median with `std::fixed` and `std::setprecision(1)`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-09-03
// Title        : Find the Running Median
// HackerRank   : https://www.hackerrank.com/challenges/find-the-running-median/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/find-the-running-median/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
6
12
4
5
3
8
7
```

### Sample Output
```text
12.0
8.0
5.0
4.5
5.0
6.0
```

## 9. Time Complexity
- **Time Complexity:** `O(N log N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Running median tracking** subtopic in Unit 3 Section 9.
