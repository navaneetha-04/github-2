# Conditional Statements in C++

## 1. Problem Title
- **Title:** Conditional Statements in C++
- **Problem ID:** `U3-02-01`
- **Topic Section:** 02. Control Flow & Decision Logic
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Conditional Statements](https://www.hackerrank.com/challenges/c-tutorial-conditional-if-else/problem)

## 3. Problem Statement Summary
Given a positive integer `n`, if `1 <= n <= 9`, print the lowercase English word corresponding to the number (e.g., `one` for `1`, `two` for `2`); otherwise, if `n > 9`, print `Greater than 9`.

## 4. Objective
Implement conditional branching, boundary checks, and constant-time lookup table indexing as a clean alternative to deeply nested `if-else` chains.

## 5. Algorithm
1. Read the input integer `n` from standard input.
2. Define a static constant lookup array `words` mapping indices `0` through `9` to their lowercase English strings.
3. Check the interval condition `if (n >= 1 && n <= 9)`.
4. If `n` lies within `[1, 9]`, output `words[n]`; otherwise output `"Greater than 9"`.

## 6. Step-by-Step Procedure
1. **Step 1 (Fast I/O & Input):** Configure fast I/O and read integer `n`.
2. **Step 2 (Lookup Table Initialization):** Create a `static const std::string words[]` table containing `"zero"` through `"nine"` so index `n` directly matches its English word.
3. **Step 3 (Boundary Evaluation):** Test whether `n` is between `1` and `9` inclusive.
4. **Step 4 (Branch Execution):** Print `words[n]` when inside the bound, or `"Greater than 9"` when `n > 9`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        static const std::string words[] = {
            "zero", "one", "two", "three", "four",
            "five", "six", "seven", "eight", "nine"
        };

        if (n >= 1 && n <= 9) {
            std::cout << words[n] << "\n";
        } else {
            std::cout << "Greater than 9\n";
        }
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5
```

### Sample Output
```text
five
```

## 9. Time Complexity
- **Time Complexity:** `O(1)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
While a beginner might write nine separate `if / else if` branches to check whether `n` equals `1`, `2`, ..., `9`, storing the English words in a fixed array `words[0..9]` lets us check the range `n >= 1 && n <= 9` once and retrieve `words[n]` directly in `O(1)` time. If `n` exceeds `9`, the `else` branch handles it immediately.

## 12. Execution Output Screenshot
![Conditional Statements in C++ Output](../../../../Output-Screenshots/U3-02-01-Conditional-Statements.png)
