# Funny String (ASCII Difference Symmetry)

## 1. Problem Title
- **Title:** Funny String (ASCII Difference Symmetry)
- **Problem ID:** `U3-04-03`
- **Topic Section:** 04. Strings & Lexical Processing
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Funny String](https://www.hackerrank.com/challenges/funny-string/problem)

## 3. Problem Statement Summary
Determine whether a string `s` is `Funny` or `Not Funny` by checking if the absolute ASCII differences between adjacent characters from left-to-right match those from right-to-left (`|s[i] - s[i-1]| == |s[n-i] - s[n-1-i]|`).

## 4. Objective
Verify symmetric adjacent ASCII differences in `O(N)` time without allocating a reversed copy of the string.

## 5. Algorithm
1. For each query string `s` of length `n`, iterate `i` from `1` to `n / 2`.
2. Compare `std::abs(s[i] - s[i - 1])` with `std::abs(s[n - i] - s[n - 1 - i])`.
3. If any pair differs, output `Not Funny`; if all match, output `Funny`.

## 6. Step-by-Step Procedure
1. **Step 1 (Read Queries):** Read test case count `q` and each string `s`.
2. **Step 2 (Two-Ended Comparison):** Compare adjacent ASCII differences from the front and back simultaneously.
3. **Step 3 (Report Result):** Print `Funny` or `Not Funny`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-04-03
// Title        : Funny String
// HackerRank   : https://www.hackerrank.com/challenges/funny-string/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/funny-string/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
acxz
bcxz
```

### Sample Output
```text
Funny
Not Funny
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **ASCII difference symmetry** subtopic in Unit 3 Section 4.
