# Super Reduced String (Stack-Based Adjacent Cancellation)

## 1. Problem Title
- **Title:** Super Reduced String (Stack-Based Adjacent Cancellation)
- **Problem ID:** `U3-04-01`
- **Topic Section:** 04. Strings & Lexical Processing
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Super Reduced String](https://www.hackerrank.com/challenges/reduced-string/problem)

## 3. Problem Statement Summary
Reduce a string of lowercase English letters by repeatedly deleting pairs of adjacent matching characters until no adjacent duplicate characters remain. If the final string is empty, print `Empty String`.

## 4. Objective
Use `std::string` as a LIFO character stack (`back()`, `push_back()`, `pop_back()`) to perform adjacent duplicate cancellation in a single linear `O(N)` pass.

## 5. Algorithm
1. Read input string `s` from standard input.
2. Initialize an empty string `stack_str = ""` to act as a character stack.
3. For each character `ch` in `s`: if `stack_str` is non-empty and `stack_str.back() == ch`, pop the top character (`stack_str.pop_back()`); otherwise push `ch` (`stack_str.push_back(ch)`).
4. After scanning all characters, print `"Empty String"` if `stack_str` is empty, or `stack_str` otherwise.

## 6. Step-by-Step Procedure
1. **Step 1 (Input):** Read the raw string `s`.
2. **Step 2 (Stack Simulation):** Iterate through every character `ch` of `s` from left to right.
3. **Step 3 (Cancellation Check):** Compare `ch` with `stack_str.back()`. If they match, both characters cancel out via `stack_str.pop_back()`, which automatically exposes the previous character for cascading cancellations (e.g., `baab` -> `bb` -> empty).
4. **Step 4 (Output Formatting):** Check `stack_str.empty()` to decide between printing `"Empty String"` or the reduced string.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    std::string s;
    if (std::cin >> s) {
        std::string stack_str = "";
        for (char ch : s) {
            if (!stack_str.empty() && stack_str.back() == ch) {
                stack_str.pop_back();
            } else {
                stack_str.push_back(ch);
            }
        }

        if (stack_str.empty()) {
            std::cout << "Empty String\n";
        } else {
            std::cout << stack_str << "\n";
        }
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
aaabccddd
```

### Sample Output
```text
abd
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
Repeatedly scanning and erasing characters from the middle of a string takes `O(N^2)` time. Instead, treating a result string `stack_str` as a stack solves the problem in `O(N)` time: each character is pushed at most once and popped at most once. Whenever two adjacent characters cancel out, the character immediately before them becomes the new `.back()`, naturally handling chain reactions.

## 12. Execution Output Screenshot
![Super Reduced String (Stack-Based Adjacent Cancellation) Output](../../../../Output-Screenshots/U3-04-01-Super-Reduced-String.png)
