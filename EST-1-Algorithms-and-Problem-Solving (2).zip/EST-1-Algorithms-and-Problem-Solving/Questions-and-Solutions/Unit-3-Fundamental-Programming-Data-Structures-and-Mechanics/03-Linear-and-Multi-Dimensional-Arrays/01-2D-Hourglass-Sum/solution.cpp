#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    std::vector<std::vector<int>> arr(6, std::vector<int>(6));
    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j < 6; ++j) {
            std::cin >> arr[i][j];
        }
    }

    int max_hourglass = -1e9;
    for (int i = 0; i <= 3; ++i) {
        for (int j = 0; j <= 3; ++j) {
            int current_sum = arr[i][j] + arr[i][j+1] + arr[i][j+2]
                                        + arr[i+1][j+1]
                            + arr[i+2][j] + arr[i+2][j+1] + arr[i+2][j+2];
            max_hourglass = std::max(max_hourglass, current_sum);
        }
    }

    std::cout << max_hourglass << "\n";
    return 0;
}
