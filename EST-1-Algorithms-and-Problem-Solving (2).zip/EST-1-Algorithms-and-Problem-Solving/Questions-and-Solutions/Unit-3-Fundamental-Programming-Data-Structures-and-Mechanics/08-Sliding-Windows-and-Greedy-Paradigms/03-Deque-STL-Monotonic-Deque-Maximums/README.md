# Deque-STL (Sliding Window Maximum via Monotonic Deque)

## 1. Problem Title
- **Title:** Deque-STL (Sliding Window Maximum via Monotonic Deque)
- **Problem ID:** `U3-08-03`
- **Topic Section:** 08. Sliding Windows & Greedy Paradigms
- **Difficulty:** Medium
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Deque-STL](https://www.hackerrank.com/challenges/deque-stl/problem)

## 3. Problem Statement Summary
Given an array of `N` integers and a window size `K`, print the maximum element in every contiguous subarray of size `K` in `O(N)` time using `std::deque`.

## 4. Objective
Maintain a monotonic decreasing double-ended queue (`std::deque<int>`) of candidate indices to query sliding window maximums in amortized `O(1)` time per step.

## 5. Algorithm
1. Maintain a `std::deque<int> dq` storing indices in strictly decreasing order of their array values.
2. For each index `i` from `0` to `N - 1`: pop front if `dq.front() <= i - K` (expired outside window).
3. While `!dq.empty()` and `arr[dq.back()] <= arr[i]`, pop back.
4. Push `i` to the back of `dq`. Once `i >= K - 1`, `arr[dq.front()]` is the current window maximum.

## 6. Step-by-Step Procedure
1. **Step 1 (Expire Old Indices):** Remove front index if it falls outside `[i - K + 1, i]`.
2. **Step 2 (Maintain Monotonic Order):** Pop smaller or equal elements from the back before inserting `i`.
3. **Step 3 (Report Maximum):** Print `arr[dq.front()]` for each completed window.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-08-03
// Title        : Deque-STL (Monotonic Deque Maximums)
// HackerRank   : https://www.hackerrank.com/challenges/deque-stl/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/deque-stl/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
5 2
3 4 6 3 4
7 4
3 4 5 8 1 4 10
```

### Sample Output
```text
4 6 6 4
8 8 8 10
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(K)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Monotonic deque maximums** subtopic in Unit 3 Section 8.
