# Sieve of Eratosthenes (Animated Composite Elimination)

## 1. Problem Title
- **Title:** Sieve of Eratosthenes (Animated Composite Elimination)
- **Problem ID:** `U3-11-01`
- **Topic Section:** 11. Complexity & Sorting Analysis
- **Difficulty:** Easy
- **Language:** C (Uploaded Visualizer)
- **Status:** Completed (Uploaded C Visualizer)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Uploaded Console Visualizer)

## 3. Problem Statement Summary
Generate all prime numbers up to `N = 30` using the Sieve of Eratosthenes by iteratively eliminating multiples of each prime `i` starting from `i * i`, with animated console color coding.

## 4. Objective
Understand why composite elimination starts at `i * i` (corresponding to `O(sqrt(N))` outer prime bound and `O(N log log N)` harmonic sieve complexity).

## 5. Algorithm
1. Initialize boolean array `prime[0..N]` to `1`, then mark `prime[0] = 0` and `prime[1] = 0`.
2. Loop `i` from `2` to `N`: if `prime[i] == 1`, iterate `j` from `i * i` to `N` in steps of `i` and mark `prime[j] = 0`.
3. Render the sieve grid after each composite elimination (yellow for current prime `i`, green for remaining prime candidates, red for eliminated composites).
4. Display the final grid of prime numbers.

## 6. Step-by-Step Procedure
1. **Step 1 (Candidate Initialization):** Set `prime[2..N] = 1` and mark `0` and `1` as non-prime.
2. **Step 2 (Square-Root Composite Crossing):** For each prime `i`, start crossing off multiples at `j = i * i` because any smaller multiple `k * i` (`k < i`) was already crossed off by a smaller prime factor of `k`.
3. **Step 3 (Console Visualization):** Render numbers `1..30` in a 6-column matrix with color attributes.

## 7. C++ Source Code (`solution.c`)
```c
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

#define N 30

int main()
{
    int prime[N + 1];
    int i, j, k;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    for(i = 0; i <= N; i++)
        prime[i] = 1;

    prime[0] = 0;
    prime[1] = 0;

    for(i = 2; i <= N; i++)
    {
        if(prime[i] == 1)
        {
            for(j = i * i; j <= N; j += i)
            {
                if(i * i > N)
                    break;

                prime[j] = 0;

                system("cls");

                printf("\n\n   SIEVE OF ERATOSTHENES\n\n");

                for(k = 1; k <= N; k++)
                {
                    if(k == i)
                        SetConsoleTextAttribute(h, 14);
                    else if(prime[k] == 0)
                        SetConsoleTextAttribute(h, 12);
                    else
                        SetConsoleTextAttribute(h, 10);

                    printf("  [%02d] ", k);

                    if(k % 6 == 0)
                        printf("\n");
                }

                Sleep(400);
            }
        }
    }

    system("cls");

    printf("\n\n   FINAL PRIME NUMBERS\n\n");

    for(i = 2; i <= N; i++)
    {
        if(prime[i] == 1)
            SetConsoleTextAttribute(h, 10);
        else
            SetConsoleTextAttribute(h, 12);

        printf("  [%02d] ", i);

        if(i % 6 == 0)
            printf("\n");
    }

    SetConsoleTextAttribute(h, 7);

    printf("\n\n   ALL PRIMES FOUND!\n");

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
N = 30 (Defined via #define N 30)
```

### Sample Output
```text
Primes highlighted in green: 02, 03, 05, 07, 11, 13, 17, 19, 23, 29
ALL PRIMES FOUND!
```

## 9. Time Complexity
- **Time Complexity:** `O(N log log N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
This is your original uploaded C Sieve of Eratosthenes simulation preserved verbatim. Starting the inner loop at `j = i * i` (and breaking when `i * i > N`) demonstrates the fundamental `sqrt(N)` factor bound: every composite number `<= N` must have at least one prime factor `<= sqrt(N)`.
