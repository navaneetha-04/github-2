#include <iostream>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    std::string s;
    if (std::cin >> s) {
        std::string stack_str = "";
        for (char ch : s) {
            if (!stack_str.empty() && stack_str.back() == ch) {
                stack_str.pop_back();
            } else {
                stack_str.push_back(ch);
            }
        }

        if (stack_str.empty()) {
            std::cout << "Empty String\n";
        } else {
            std::cout << stack_str << "\n";
        }
    }

    return 0;
}
