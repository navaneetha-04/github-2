# 2D Array Spiral Traversal (Interactive Visualizer)

## 1. Problem Title
- **Title:** 2D Array Spiral Traversal (Interactive Visualizer)
- **Problem ID:** `U3-03-02`
- **Topic Section:** 03. Linear & Multi-Dimensional Arrays
- **Difficulty:** Medium
- **Language:** C (Uploaded Visualizer)
- **Status:** Completed (Uploaded C Visualizer)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Uploaded Console Visualizer)

## 3. Problem Statement Summary
Traverse a `3 x 3` 2D matrix in clockwise spiral order (`1 -> 2 -> 3 -> 6 -> 9 -> 8 -> 7 -> 4 -> 5`) and animate the active cell in the console.

## 4. Objective
Visualize 2D row/column index flattening (`i * 3 + j` and `pos / 3`, `pos % 3`) and clockwise spiral order traversal.

## 5. Algorithm
1. Initialize the `3 x 3` matrix `a` with values `1..9` and the flattened spiral index sequence `path[] = {0, 1, 2, 5, 8, 7, 6, 3, 4}`.
2. Acquire the Windows console output handle (`GetStdHandle(STD_OUTPUT_HANDLE)`).
3. For each step `k` from `0` to `8`, clear the screen and highlight cell `(i, j)` in yellow (`14`) if `i * 3 + j == path[k]`, or cyan (`11`) otherwise.
4. Print the cumulative spiral sequence visited so far (`a[path[i] / 3][path[i] % 3]`) and pause for `700 ms`.

## 6. Step-by-Step Procedure
1. **Step 1 (Matrix & Path Definition):** Define the `3 x 3` grid `a` and flattened 1D spiral coordinates `path[]`.
2. **Step 2 (Frame Rendering Loop):** Loop `k` over all 9 cells, clearing the terminal each frame.
3. **Step 3 (2D-to-1D Coordinate Mapping):** Match the 2D position `(i, j)` against the active flattened index `pos = path[k]` via `i * 3 + j == pos`.
4. **Step 4 (1D-to-2D Reconstruction):** Recover the row `path[i] / 3` and column `path[i] % 3` to display the running spiral sequence.

## 7. C++ Source Code (`solution.c`)
```c
#include <stdio.h>
#include <windows.h>

int main()
{
    int a[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    int path[] = {0, 1, 2, 5, 8, 7, 6, 3, 4};

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    int i, j, k, pos;

    for(k = 0; k < 9; k++)
    {
        system("cls");

        pos = path[k];

        printf("\n       2D ARRAY SPIRAL TRAVERSAL\n\n");

        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 3; j++)
            {
                if(i * 3 + j == pos)
                    SetConsoleTextAttribute(h, 14);
                else
                    SetConsoleTextAttribute(h, 11);

                printf("   [ %d ]   ", a[i][j]);
            }
            printf("\n\n");
        }

        SetConsoleTextAttribute(h, 7);

        printf("\n   Spiral Order: ");

        for(i = 0; i <= k; i++)
            printf("%d ", a[path[i] / 3][path[i] % 3]);

        Sleep(700);
    }

    SetConsoleTextAttribute(h, 7);
    printf("\n\n   Spiral Completed!\n");

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
[Embedded 3x3 matrix: {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}]
```

### Sample Output
```text
Spiral Order: 1 2 3 6 9 8 7 4 5
Spiral Completed!
```

## 9. Time Complexity
- **Time Complexity:** `O(R * C)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
This is your original uploaded C visualizer preserved with its exact working logic. It demonstrates how any 2D coordinate `(i, j)` in a matrix with `C` columns maps to a single 1D index `pos = i * C + j`, and inversely how `pos / C` recovers the row and `pos % C` recovers the column.

## 12. Execution Output Screenshot
![2D Array Spiral Traversal (Interactive Visualizer) Output](../../../../Output-Screenshots/U3-03-02-Matrix-Spiral-Traversal.png)
