#include <iostream>
#include <iomanip>

int main() {
    // Fast I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int i;
    long l;
    char c;
    float f;
    double d;

    if (std::cin >> i >> l >> c >> f >> d) {
        std::cout << i << "\n";
        std::cout << l << "\n";
        std::cout << c << "\n";
        std::cout << std::fixed << std::setprecision(3) << f << "\n";
        std::cout << std::fixed << std::setprecision(9) << d << "\n";
    }

    return 0;
}
