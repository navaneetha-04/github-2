# Array Manipulation (Difference Array & Prefix Sums)

## 1. Problem Title
- **Title:** Array Manipulation (Difference Array & Prefix Sums)
- **Problem ID:** `U3-07-01`
- **Topic Section:** 07. Pre-computation & Range Techniques
- **Difficulty:** Hard
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Array Manipulation](https://www.hackerrank.com/challenges/crush/problem)

## 3. Problem Statement Summary
Starting with a 1-indexed array of `n` zeros, perform `m` range addition queries where each query adds `k` to all elements between indices `a` and `b` inclusive. Return the maximum value in the array after all `m` operations.

## 4. Objective
Transform `O(N)` range addition updates into `O(1)` point updates using a Difference Array (`diff[a] += k`, `diff[b + 1] -= k`) followed by a single `O(N)` prefix sum sweep.

## 5. Algorithm
1. Read array size `n` and operation count `m`.
2. Allocate a 64-bit difference array `std::vector<long long> diff(n + 2, 0)`.
3. For each query `(a, b, k)`, increment `diff[a] += k` and decrement `diff[b + 1] -= k` in `O(1)` time.
4. Sweep `i` from `1` to `n`, maintaining the running prefix sum `current += diff[i]` and updating `max_val = std::max(max_val, current)`.
5. Print `max_val`.

## 6. Step-by-Step Procedure
1. **Step 1 (Difference Array Setup):** Initialize `diff` of size `n + 2` with `0LL` so 1-based index `b + 1` never goes out of bounds when `b == n`.
2. **Step 2 (O(1) Range Marking):** For each range `[a, b]`, add `k` at the start boundary `a` and subtract `k` immediately after the end boundary `b + 1`.
3. **Step 3 (Prefix Sum Reconstruction):** Accumulate `current += diff[i]` from `i = 1` to `n`. At any index `i`, `current` equals the exact sum of all intervals covering `i`.
4. **Step 4 (Peak Tracking):** Track and print the maximum value reached by `current`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    long long n, m;
    if (std::cin >> n >> m) {
        std::vector<long long> diff(n + 2, 0);

        for (int i = 0; i < m; ++i) {
            long long a, b, k;
            std::cin >> a >> b >> k;
            diff[a] += k;
            diff[b + 1] -= k;
        }

        long long max_val = 0;
        long long current = 0;
        for (int i = 1; i <= n; ++i) {
            current += diff[i];
            max_val = std::max(max_val, current);
        }

        std::cout << max_val << "\n";
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5 3
1 2 100
2 5 100
3 4 100
```

### Sample Output
```text
200
```

## 9. Time Complexity
- **Time Complexity:** `O(N + M)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
With `n <= 10^7` and `m <= 2 * 10^5`, updating every index from `a` to `b` in a loop would require up to `2 * 10^12` operations and Time Limit Exceeded (TLE). A Difference Array records only the slope changes: `+k` entering the interval at `a`, and `-k` leaving the interval at `b + 1`. Taking the prefix sum at the end reconstructs the final array values in a single `O(N)` pass.
