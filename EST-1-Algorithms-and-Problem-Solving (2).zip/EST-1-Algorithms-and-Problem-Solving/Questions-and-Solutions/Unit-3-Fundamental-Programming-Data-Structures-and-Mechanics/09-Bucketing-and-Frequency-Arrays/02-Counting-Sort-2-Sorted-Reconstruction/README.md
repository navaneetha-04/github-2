# Counting Sort 2 (Sorted Array Reconstruction)

## 1. Problem Title
- **Title:** Counting Sort 2 (Sorted Array Reconstruction)
- **Problem ID:** `U3-09-02`
- **Topic Section:** 09. Bucketing & Frequency Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Counting Sort 2](https://www.hackerrank.com/challenges/countingsort2/problem)

## 3. Problem Statement Summary
Given an unsorted list of integers in the range `[0, 99]`, count occurrences using a 100-bucket frequency array and output the full sorted sequence.

## 4. Objective
Extend frequency array bucketing (`Counting Sort 1`) to reconstruct the sorted output in `O(N + K)` time.

## 5. Algorithm
1. Populate `freq[0..99]` in `O(N)` time.
2. For `val` from `0` to `99`, print `val` exactly `freq[val]` times.

## 6. Step-by-Step Procedure
1. **Step 1 (Frequency Count):** Tally occurrences in `freq[100]`.
2. **Step 2 (Bucket Emission):** Iterate through buckets `0..99` in ascending order and emit each value according to its frequency.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-09-02
// Title        : Counting Sort 2
// HackerRank   : https://www.hackerrank.com/challenges/countingsort2/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/countingsort2/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
6
1 1 3 2 1 0
```

### Sample Output
```text
0 1 1 1 2 3
```

## 9. Time Complexity
- **Time Complexity:** `O(N + K)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(K) (K = 100)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Counting Sort** reconstruction subtopic in Unit 3 Section 9.
