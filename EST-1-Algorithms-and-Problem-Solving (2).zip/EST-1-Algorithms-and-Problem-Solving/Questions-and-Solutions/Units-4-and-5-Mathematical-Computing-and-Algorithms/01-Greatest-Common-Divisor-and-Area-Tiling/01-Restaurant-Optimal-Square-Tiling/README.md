# Restaurant (Optimal Square Tiling via Euclidean GCD)

## 1. Problem Title
- **Title:** Restaurant (Optimal Square Tiling via Euclidean GCD)
- **Problem ID:** `U4-01-01`
- **Topic Section:** 01. Greatest Common Divisor & Area Tiling
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Restaurant](https://www.hackerrank.com/challenges/restaurant/problem)

## 3. Problem Statement Summary
Martha is cutting a rectangular loaf of bread of dimensions `l x b` into smaller identical squares of maximum possible side length such that no bread is left over. Compute the number of squares of maximum size she can cut.

## 4. Objective
Apply the Euclidean Algorithm (`gcd(a, b) = gcd(b, a % b)`) to find the largest square tile dimension `g = gcd(l, b)` that evenly divides both `l` and `b`.

## 5. Algorithm
1. Read test case count `t`.
2. For each test case, read dimensions `l` and `b`.
3. Compute `g = gcd(l, b)` using the iterative Euclidean algorithm (`while (b) { a %= b; std::swap(a, b); }`).
4. Compute the total number of `g x g` squares as `(l / g) * (b / g)` and print it.

## 6. Step-by-Step Procedure
1. **Step 1 (Euclidean GCD Function):** Implement `gcd(long long a, long long b)` using modulo reduction in `O(log(min(a, b)))` time.
2. **Step 2 (Optimal Tile Side):** For a square of side `g` to tile an `l x b` rectangle without leftover bread, `g` must divide both `l` and `b`. To maximize square size (and minimize piece count), `g` must be `gcd(l, b)`.
3. **Step 3 (Grid Count Calculation):** Divide length into `l / g` segments and breadth into `b / g` segments, giving `(l / g) * (b / g)` total squares.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>

long long gcd(long long a, long long b) {
    while (b) {
        a %= b;
        std::swap(a, b);
    }
    return a;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int t;
    if (std::cin >> t) {
        while (t--) {
            long long l, b;
            std::cin >> l >> b;
            long long g = gcd(l, b);
            long long count = (l / g) * (b / g);
            std::cout << count << "\n";
        }
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
2 2
6 9
```

### Sample Output
```text
1
6
```

## 9. Time Complexity
- **Time Complexity:** `O(T * log(min(l, b)))`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
If we cut an `l x b` rectangle into identical `s x s` squares with zero waste, the side length `s` must divide `l` evenly and divide `b` evenly. The largest such `s` is by definition the **Greatest Common Divisor** `g = gcd(l, b)`. Once `g` is found via the Euclidean Algorithm, `(l / g)` squares fit along the length and `(b / g)` fit along the width, yielding `(l / g) * (b / g)` squares in total.

## 12. Execution Output Screenshot
![Restaurant (Optimal Square Tiling via Euclidean GCD) Output](../../../../Output-Screenshots/U4-01-01-Restaurant-Tiling.png)
