# CamelCase (Word Boundaries)

## 1. Problem Title
- **Title:** CamelCase (Word Boundaries)
- **Problem ID:** `U3-04-02`
- **Topic Section:** 04. Strings & Lexical Processing
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [CamelCase](https://www.hackerrank.com/challenges/camelcase/problem)

## 3. Problem Statement Summary
Given a `camelCase` string `s`, determine the total number of words in `s`. The first word is all lowercase, and each subsequent word begins with an uppercase English letter.

## 4. Objective
Detect lexical word boundaries by counting ASCII uppercase transitions (`'A' <= c && c <= 'Z'` or `std::isupper`).

## 5. Algorithm
1. Read string `s`.
2. Initialize word counter `words = 1` (since `s` is non-empty and starts with a lowercase word).
3. Iterate through each character `c` in `s`: increment `words` whenever `c >= 'A' && c <= 'Z'`.
4. Output `words`.

## 6. Step-by-Step Procedure
1. **Step 1 (Read String):** Read the camelCase identifier `s`.
2. **Step 2 (Scan Uppercase Transitions):** Count how many characters fall in the uppercase ASCII range `['A', 'Z']`.
3. **Step 3 (Output):** Print `1 + uppercase_count`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-04-02
// Title        : CamelCase
// HackerRank   : https://www.hackerrank.com/challenges/camelcase/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/camelcase/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
saveChangesInTheEditor
```

### Sample Output
```text
5
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Word boundaries** subtopic in Unit 3 Section 4.
