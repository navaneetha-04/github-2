# Handshake (Complete Graph Combinatorics)

## 1. Problem Title
- **Title:** Handshake (Complete Graph Combinatorics)
- **Problem ID:** `U4-04-02`
- **Topic Section:** 04. Permutations & Combinations
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Handshake](https://www.hackerrank.com/challenges/handshake/problem)

## 3. Problem Statement Summary
At the annual meeting of the Board of Directors of Acme Inc, every attendee shakes hands exactly once with every other attendee. Given `n` attendees, find the total number of handshakes.

## 4. Objective
Model pairwise interactions as edges in a complete graph `K_n`, computing `C(n, 2) = n * (n - 1) / 2` in `O(1)` time.

## 5. Algorithm
1. Read test case count `t`.
2. For each test case, read 64-bit integer `n`.
3. Compute `handshakes = (n * (n - 1)) / 2` and print the result.

## 6. Step-by-Step Procedure
1. **Step 1 (64-Bit Input):** Read `n` as `long long` so `n * (n - 1)` does not overflow when `n` approaches `10^6`.
2. **Step 2 (Closed-Form Evaluation):** Calculate `(n * (n - 1)) / 2` in `O(1)` time and output.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int t;
    if (std::cin >> t) {
        while (t--) {
            long long n;
            std::cin >> n;
            long long handshakes = (n * (n - 1)) / 2;
            std::cout << handshakes << "\n";
        }
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
2
1
2
```

### Sample Output
```text
0
1
```

## 9. Time Complexity
- **Time Complexity:** `O(1) per testcase`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
Choosing 2 people out of `n` to shake hands (where order does not matter) is the combination `C(n, 2) = n * (n - 1) / 2`, which also equals the number of edges in a complete undirected graph `K_n` with `n` vertices.

## 12. Execution Output Screenshot
![Handshake (Complete Graph Combinatorics) Output](../../../../Output-Screenshots/U4-04-02-Handshake.png)
