# For Loop (Interval Iteration & Ternary Parity Logic)

## 1. Problem Title
- **Title:** For Loop (Interval Iteration & Ternary Parity Logic)
- **Problem ID:** `U3-02-02`
- **Topic Section:** 02. Control Flow & Decision Logic
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [For Loop](https://www.hackerrank.com/challenges/c-tutorial-for-loop/problem)

## 3. Problem Statement Summary
Given two positive integers `a` and `b` (`a <= b`), iterate over every integer `i` in the inclusive interval `[a, b]`. If `1 <= i <= 9`, print its English word representation; if `i > 9`, print `even` if `i` is even, or `odd` if `i` is odd.

## 4. Objective
Master inclusive loop boundaries (`for (int i = a; i <= b; ++i)`), multi-branch conditions, and ternary operators (`(i % 2 == 0) ? "even" : "odd"`).

## 5. Algorithm
1. Read the inclusive interval bounds `a` and `b`.
2. Loop `i` from `a` to `b` inclusive.
3. If `1 <= i <= 9`, print the English word from a lookup table.
4. Else if `i > 9`, use the modulo operator `i % 2 == 0` (or ternary operator) to print `even` or `odd`.

## 6. Step-by-Step Procedure
1. **Step 1 (Read Bounds):** Read integers `a` and `b` from standard input.
2. **Step 2 (Loop Construction):** Run a `for` loop starting at `i = a` and terminating after `i = b`.
3. **Step 3 (Decision Logic):** Inside the loop, branch on `i <= 9` vs `i > 9`, and use `(i % 2 == 0 ? "even" : "odd")` for numbers greater than 9.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-02-02
// Title        : For Loop
// HackerRank   : https://www.hackerrank.com/challenges/c-tutorial-for-loop/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/c-tutorial-for-loop/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
8
11
```

### Sample Output
```text
eight
nine
even
odd
```

## 9. Time Complexity
- **Time Complexity:** `O(b - a + 1)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
This problem is marked as **Pending** because it was not included in your uploaded C++ programs. It extends `U3-02-01` by wrapping the conditional check inside a `for` loop across `[a, b]` and using a ternary parity check for values above `9`.
