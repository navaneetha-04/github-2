#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

#define N 30

int main()
{
    int prime[N + 1];
    int i, j, k;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    for(i = 0; i <= N; i++)
        prime[i] = 1;

    prime[0] = 0;
    prime[1] = 0;

    for(i = 2; i <= N; i++)
    {
        if(prime[i] == 1)
        {
            for(j = i * i; j <= N; j += i)
            {
                if(i * i > N)
                    break;

                prime[j] = 0;

                system("cls");

                printf("\n\n   SIEVE OF ERATOSTHENES\n\n");

                for(k = 1; k <= N; k++)
                {
                    if(k == i)
                        SetConsoleTextAttribute(h, 14);
                    else if(prime[k] == 0)
                        SetConsoleTextAttribute(h, 12);
                    else
                        SetConsoleTextAttribute(h, 10);

                    printf("  [%02d] ", k);

                    if(k % 6 == 0)
                        printf("\n");
                }

                Sleep(400);
            }
        }
    }

    system("cls");

    printf("\n\n   FINAL PRIME NUMBERS\n\n");

    for(i = 2; i <= N; i++)
    {
        if(prime[i] == 1)
            SetConsoleTextAttribute(h, 10);
        else
            SetConsoleTextAttribute(h, 12);

        printf("  [%02d] ", i);

        if(i % 6 == 0)
            printf("\n");
    }

    SetConsoleTextAttribute(h, 7);

    printf("\n\n   ALL PRIMES FOUND!\n");

    return 0;
}
