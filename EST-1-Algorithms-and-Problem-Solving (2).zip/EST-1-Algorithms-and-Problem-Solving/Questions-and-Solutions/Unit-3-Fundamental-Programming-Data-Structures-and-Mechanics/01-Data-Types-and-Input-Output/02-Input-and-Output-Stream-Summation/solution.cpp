// ============================================================================
// Problem ID   : U3-01-02
// Title        : Input and Output
// HackerRank   : https://www.hackerrank.com/challenges/cpp-input-and-output/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/cpp-input-and-output/problem

    return 0;
}
