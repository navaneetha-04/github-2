# Recursion: Davis' Staircase

## 1. Problem Title
- **Title:** Recursion: Davis' Staircase
- **Problem ID:** `U3-10-04`
- **Topic Section:** 10. Recursion & Combinatorics
- **Difficulty:** Medium
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Recursion: Davis' Staircase](https://www.hackerrank.com/challenges/ctci-recursive-staircase/problem)

## 3. Problem Statement Summary
Davis can climb `1`, `2`, or `3` steps at a time. Given a staircase of height `n`, find the number of distinct ways to reach the top modulo `10^10 + 7`.

## 4. Objective
Apply memoized recursion (Tribonacci recurrence `ways(n) = ways(n-1) + ways(n-2) + ways(n-3)`) to avoid exponential `O(3^N)` recomputation.

## 5. Algorithm
1. Base cases: `ways(0) = 1`, `ways(1) = 1`, `ways(2) = 2`.
2. For `i` from `3` to `n`, compute `dp[i] = (dp[i-1] + dp[i-2] + dp[i-3]) % 10000000007LL`.

## 6. Step-by-Step Procedure
1. **Step 1 (Memoization Table):** Create a cache array `memo[n + 1]`.
2. **Step 2 (Recursive/DP Evaluation):** Compute `ways(n)` using the 3-step recurrence.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-10-04
// Title        : Recursion: Davis' Staircase
// HackerRank   : https://www.hackerrank.com/challenges/ctci-recursive-staircase/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/ctci-recursive-staircase/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
3
1
3
7
```

### Sample Output
```text
1
4
44
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N)`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Davis Staircase** subtopic in Unit 3 Section 10.
