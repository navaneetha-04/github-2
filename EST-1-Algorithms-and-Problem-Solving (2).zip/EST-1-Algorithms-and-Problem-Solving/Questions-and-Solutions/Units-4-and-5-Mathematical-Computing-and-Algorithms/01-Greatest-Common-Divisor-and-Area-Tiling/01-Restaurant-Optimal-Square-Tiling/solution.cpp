#include <iostream>

long long gcd(long long a, long long b) {
    while (b) {
        a %= b;
        std::swap(a, b);
    }
    return a;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int t;
    if (std::cin >> t) {
        while (t--) {
            long long l, b;
            std::cin >> l >> b;
            long long g = gcd(l, b);
            long long count = (l / g) * (b / g);
            std::cout << count << "\n";
        }
    }

    return 0;
}
