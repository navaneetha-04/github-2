# Pascal's Triangle (Dynamic Binomial Coefficient Computation)

## 1. Problem Title
- **Title:** Pascal's Triangle (Dynamic Binomial Coefficient Computation)
- **Problem ID:** `U4-05-01`
- **Topic Section:** 05. Pascal's Triangle
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** Pending Verification (Core C++14 Reference Module)

## 3. Problem Statement Summary
Given an integer `n`, generate the first `n` rows of Pascal's Triangle using the dynamic programming recurrence `C(i, j) = C(i - 1, j - 1) + C(i - 1, j)`.

## 4. Objective
Compute binomial coefficients dynamically using addition only, avoiding division and intermediate factorial overflow.

## 5. Algorithm
1. Read row count `n`.
2. Allocate `std::vector<std::vector<long long>> triangle(n)`.
3. For each row `i` from `0` to `n - 1`: resize `triangle[i]` to length `i + 1` initialized with `1`s (setting boundary values `C(i, 0) = C(i, i) = 1`).
4. For interior columns `j` from `1` to `i - 1`, compute `triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j]`.
5. Print each row `i` with space-separated binomial coefficients.

## 6. Step-by-Step Procedure
1. **Step 1 (Row Initialization):** Resize row `i` to `i + 1` elements filled with `1` so both endpoints `triangle[i][0]` and `triangle[i][i]` are automatically `1`.
2. **Step 2 (Pascal's Recurrence):** Fill interior cells `1 <= j < i` by summing the two cells directly above from row `i - 1`.
3. **Step 3 (Output):** Print the `n` rows of Pascal's Triangle.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        std::vector<std::vector<long long>> triangle(n);
        for (int i = 0; i < n; ++i) {
            triangle[i].resize(i + 1, 1);
            for (int j = 1; j < i; ++j) {
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
            }
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j <= i; ++j) {
                std::cout << triangle[i][j] << (j == i ? "" : " ");
            }
            std::cout << "\n";
        }
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5
```

### Sample Output
```text
1
1 1
1 2 1
1 3 3 1
1 4 6 4 1
```

## 9. Time Complexity
- **Time Complexity:** `O(N^2)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(N^2)`

## 11. Explanation of the Program
Computing `C(n, k) = n! / (k! (n - k)!)` directly fails for `n > 20` because `n!` overflows a 64-bit integer, even when `C(n, k)` itself is small. Pascal's identity `C(i, j) = C(i - 1, j - 1) + C(i - 1, j)` builds every binomial coefficient using pure addition from the previous row in `O(N^2)` time.
