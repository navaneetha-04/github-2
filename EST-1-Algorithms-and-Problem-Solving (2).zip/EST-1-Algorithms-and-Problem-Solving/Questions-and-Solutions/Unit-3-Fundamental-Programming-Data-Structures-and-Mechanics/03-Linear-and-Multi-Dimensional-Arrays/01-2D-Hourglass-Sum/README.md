# 2D Array - DS (Hourglass Sum)

## 1. Problem Title
- **Title:** 2D Array - DS (Hourglass Sum)
- **Problem ID:** `U3-03-01`
- **Topic Section:** 03. Linear & Multi-Dimensional Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [2D Array - DS](https://www.hackerrank.com/challenges/2d-array/problem)

## 3. Problem Statement Summary
Given a `6 x 6` 2D array of integers, calculate the hourglass sum for every hourglass pattern in the matrix and print the maximum hourglass sum.

## 4. Objective
Practice 2D matrix indexing, bounded subgrid traversal (`0 <= i, j <= 3`), and negative maximum initialization.

## 5. Algorithm
1. Allocate a `6 x 6` 2D vector `arr` and read all 36 integers from standard input.
2. Initialize `max_hourglass = -1e9` (important because cell values can be negative down to `-9`, making the minimum possible hourglass sum `-63`).
3. Iterate top-left anchor row `i` from `0` to `3` and column `j` from `0` to `3`.
4. Sum the 7 cells belonging to the hourglass anchored at `(i, j)`: top row `(i, j..j+2)`, middle center `(i+1, j+1)`, and bottom row `(i+2, j..j+2)`.
5. Update `max_hourglass = std::max(max_hourglass, current_sum)` and print `max_hourglass`.

## 6. Step-by-Step Procedure
1. **Step 1 (Matrix Input):** Read the `6 x 6` integer grid into `std::vector<std::vector<int>> arr(6, std::vector<int>(6))`.
2. **Step 2 (Safe Initialization):** Set `max_hourglass` to a large negative sentinel (`-1e9`) rather than `0`, since all hourglass sums could be negative.
3. **Step 3 (Subgrid Scanning):** Loop `i` in `[0, 3]` and `j` in `[0, 3]` so `i + 2` and `j + 2` never go out of bounds (`< 6`).
4. **Step 4 (Accumulation & Comparison):** Add the 7 hourglass offsets, update the maximum using `std::max`, and output the final maximum.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    std::vector<std::vector<int>> arr(6, std::vector<int>(6));
    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j < 6; ++j) {
            std::cin >> arr[i][j];
        }
    }

    int max_hourglass = -1e9;
    for (int i = 0; i <= 3; ++i) {
        for (int j = 0; j <= 3; ++j) {
            int current_sum = arr[i][j] + arr[i][j+1] + arr[i][j+2]
                                        + arr[i+1][j+1]
                            + arr[i+2][j] + arr[i+2][j+1] + arr[i+2][j+2];
            max_hourglass = std::max(max_hourglass, current_sum);
        }
    }

    std::cout << max_hourglass << "\n";
    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
1 1 1 0 0 0
0 1 0 0 0 0
1 1 1 0 0 0
0 0 2 4 4 0
0 0 0 2 0 0
0 0 1 2 4 0
```

### Sample Output
```text
19
```

## 9. Time Complexity
- **Time Complexity:** `O(1) for fixed 6x6 grid (O(R * C) generalized)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1)`

## 11. Explanation of the Program
An hourglass in a 2D grid spans 3 rows and 3 columns (7 cells total). In a `6 x 6` grid, there are `4 x 4 = 16` valid top-left corners `(i, j)` where `0 <= i, j <= 3`. For each top-left corner, the program adds the 3 top elements, 1 middle center element, and 3 bottom elements, tracking the highest sum found. Initializing `max_hourglass = -1e9` avoids a classic bug where all-negative matrices erroneously return `0`.

## 12. Execution Output Screenshot
![2D Array - DS (Hourglass Sum) Output](../../../../Output-Screenshots/U3-03-01-2D-Hourglass-Sum.png)
