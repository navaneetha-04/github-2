#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        std::vector<std::vector<long long>> triangle(n);
        for (int i = 0; i < n; ++i) {
            triangle[i].resize(i + 1, 1);
            for (int j = 1; j < i; ++j) {
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
            }
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j <= i; ++j) {
                std::cout << triangle[i][j] << (j == i ? "" : " ");
            }
            std::cout << "\n";
        }
    }

    return 0;
}
