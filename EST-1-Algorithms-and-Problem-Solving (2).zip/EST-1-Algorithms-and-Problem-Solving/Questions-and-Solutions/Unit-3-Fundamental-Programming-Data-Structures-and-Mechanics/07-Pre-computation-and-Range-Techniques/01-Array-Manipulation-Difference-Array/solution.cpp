#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    long long n, m;
    if (std::cin >> n >> m) {
        std::vector<long long> diff(n + 2, 0);

        for (int i = 0; i < m; ++i) {
            long long a, b, k;
            std::cin >> a >> b >> k;
            diff[a] += k;
            diff[b + 1] -= k;
        }

        long long max_val = 0;
        long long current = 0;
        for (int i = 1; i <= n; ++i) {
            current += diff[i];
            max_val = std::max(max_val, current);
        }

        std::cout << max_val << "\n";
    }

    return 0;
}
