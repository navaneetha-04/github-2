# Diagonal Difference (Matrix Diagonals)

## 1. Problem Title
- **Title:** Diagonal Difference (Matrix Diagonals)
- **Problem ID:** `U3-03-05`
- **Topic Section:** 03. Linear & Multi-Dimensional Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Pending

## 2. HackerRank Problem Link
- **HackerRank Link:** [Diagonal Difference](https://www.hackerrank.com/challenges/diagonal-difference/problem)

## 3. Problem Statement Summary
Given a square matrix of size `N x N`, calculate the absolute difference between the sums of its primary diagonal (`i == j`) and secondary diagonal (`i + j == N - 1`).

## 4. Objective
Master primary (`arr[i][i]`) and anti-diagonal (`arr[i][N - 1 - i]`) indexing in a 2D square matrix.

## 5. Algorithm
1. Read matrix dimension `N` and the `N x N` integers.
2. Initialize `primary_sum = 0` and `secondary_sum = 0`.
3. For `i` from `0` to `N - 1`, add `arr[i][i]` to `primary_sum` and `arr[i][N - 1 - i]` to `secondary_sum`.
4. Return `std::abs(primary_sum - secondary_sum)`.

## 6. Step-by-Step Procedure
1. **Step 1 (Matrix Read):** Read `N` and the matrix elements.
2. **Step 2 (Diagonal Accumulation):** In a single loop over row `i`, accumulate `arr[i][i]` and `arr[i][N - 1 - i]`.
3. **Step 3 (Absolute Difference):** Compute and print `std::abs(primary_sum - secondary_sum)`.

## 7. C++ Source Code (`solution.cpp`)
```cpp
// ============================================================================
// Problem ID   : U3-03-05
// Title        : Diagonal Difference
// HackerRank   : https://www.hackerrank.com/challenges/diagonal-difference/problem
// Standard     : C++14
// Status       : Pending (Not yet uploaded / verified in user submissions)
// ============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    // Fast standard I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    // TODO: Pending verified HackerRank C++14 submission.
    // Implement and verify solution at: https://www.hackerrank.com/challenges/diagonal-difference/problem

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
3
11 2 4
4 5 6
10 8 -12
```

### Sample Output
```text
15
```

## 9. Time Complexity
- **Time Complexity:** `O(N^2) to read matrix, O(N) to sum diagonals`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1) if summed on the fly`

## 11. Explanation of the Program
Marked as **Pending** (not yet uploaded). Covers the **Matrix diagonals** subtopic in Unit 3 Section 3.
