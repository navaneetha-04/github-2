# Running Time of Algorithms (Insertion Sort Shift & Inversion Counting)

## 1. Problem Title
- **Title:** Running Time of Algorithms (Insertion Sort Shift & Inversion Counting)
- **Problem ID:** `U3-11-02`
- **Topic Section:** 11. Complexity & Sorting Analysis
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Running Time of Algorithms](https://www.hackerrank.com/challenges/runningtime/problem)

## 3. Problem Statement Summary
Given an array of `n` integers, sort the array using Insertion Sort and output the total number of element shifts performed during the sort.

## 4. Objective
Analyze the empirical running time of Insertion Sort by counting inner-loop shifts, which equals the number of inversions in the input array (`O(N^2)` worst case, `O(N)` best case).

## 5. Algorithm
1. Read array length `n` and `n` integers into `std::vector<int> arr(n)`.
2. Initialize `shift_count = 0`.
3. For `i` from `1` to `n - 1`: save `key = arr[i]` and set `j = i - 1`.
4. While `j >= 0 && arr[j] > key`, shift `arr[j + 1] = arr[j]`, decrement `j--`, and increment `shift_count++`.
5. Insert `arr[j + 1] = key` and print `shift_count` after the outer loop finishes.

## 6. Step-by-Step Procedure
1. **Step 1 (Array Input):** Read `n` and populate `arr`.
2. **Step 2 (Insertion Sort Outer Loop):** Partition the array into a sorted prefix `arr[0..i-1]` and current element `key = arr[i]`.
3. **Step 3 (Shift & Count):** Move every element in the sorted prefix that is strictly greater than `key` one position to the right, incrementing `shift_count` on each shift.
4. **Step 4 (Output):** Print the total shift count.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        std::vector<int> arr(n);
        for (int i = 0; i < n; ++i) {
            std::cin >> arr[i];
        }

        int shift_count = 0;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
                shift_count++;
            }
            arr[j + 1] = key;
        }

        std::cout << shift_count << "\n";
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5
2 1 3 1 2
```

### Sample Output
```text
4
```

## 9. Time Complexity
- **Time Complexity:** `O(N^2) worst/average case, O(N) best case (already sorted)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1) auxiliary (in-place sort)`

## 11. Explanation of the Program
In Insertion Sort, each right-shift occurs precisely when an earlier element `arr[j]` is strictly greater than a later element `arr[i]` (`j < i` and `arr[j] > arr[i]`). Such a pair is called an **inversion**. Therefore, the total number of shifts performed by Insertion Sort equals the total number of inversions in the array—ranging from `0` for an already sorted array (`O(N)` time) to `N * (N - 1) / 2` for a reverse-sorted array (`O(N^2)` time).

## 12. Execution Output Screenshot
![Running Time of Algorithms (Insertion Sort Shift & Inversion Counting) Output](../../../../Output-Screenshots/U3-11-02-Running-Time-Insertion-Sort.png)
