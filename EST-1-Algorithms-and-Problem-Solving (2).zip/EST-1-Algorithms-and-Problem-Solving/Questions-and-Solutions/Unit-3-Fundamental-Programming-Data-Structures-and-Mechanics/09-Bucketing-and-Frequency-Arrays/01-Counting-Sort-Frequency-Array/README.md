# Counting Sort 1 (Frequency Array Bucketing)

## 1. Problem Title
- **Title:** Counting Sort 1 (Frequency Array Bucketing)
- **Problem ID:** `U3-09-01`
- **Topic Section:** 09. Bucketing & Frequency Arrays
- **Difficulty:** Easy
- **Language:** C++14
- **Status:** Completed (Uploaded C++14)

## 2. HackerRank Problem Link
- **HackerRank Link:** [Counting Sort 1](https://www.hackerrank.com/challenges/countingsort1/problem)

## 3. Problem Statement Summary
Given a list of `n` integers where each integer is in the range `[0, 99]`, construct and print a 100-element frequency array where index `i` stores the number of times value `i` appears in the input.

## 4. Objective
Use direct address bucketing (`freq[val]++`) to tally element frequencies in `O(N)` linear time without comparisons.

## 5. Algorithm
1. Read integer count `n`.
2. Initialize a frequency vector `std::vector<int> freq(100, 0)`.
3. Loop `n` times: read integer `val`, verify `0 <= val < 100`, and increment `freq[val]++`.
4. Print all 100 bucket counts separated by spaces.

## 6. Step-by-Step Procedure
1. **Step 1 (Bucket Allocation):** Create `std::vector<int> freq(100, 0)` representing buckets `0` through `99`.
2. **Step 2 (Single-Pass Tally):** Read each input number `val` and increment its corresponding bucket `freq[val]` in `O(1)` time.
3. **Step 3 (Output):** Print the 100 space-separated counts.

## 7. C++ Source Code (`solution.cpp`)
```cpp
#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (std::cin >> n) {
        std::vector<int> freq(100, 0);
        for (int i = 0; i < n; ++i) {
            int val;
            std::cin >> val;
            if (val >= 0 && val < 100) {
                freq[val]++;
            }
        }

        for (int i = 0; i < 100; ++i) {
            std::cout << freq[i] << (i == 99 ? "" : " ");
        }
        std::cout << "\n";
    }

    return 0;
}
```

## 8. Sample Input and Output

### Sample Input
```text
5
1 1 3 2 1
```

### Sample Output
```text
0 3 1 1 0 0 ... [94 zeros]
```

## 9. Time Complexity
- **Time Complexity:** `O(N)`

## 10. Auxiliary Space Complexity
- **Auxiliary Space Complexity:** `O(1) (Fixed 100 buckets)`

## 11. Explanation of the Program
Comparison-based sorting algorithms require at least `O(N log N)` operations. When input values are small integers bounded within a known range `[0, K)` (here `K = 100`), Counting Sort maps each value directly to an array index `freq[val]++`, counting all occurrences in `O(N)` time and `O(K)` space.

## 12. Execution Output Screenshot
![Counting Sort 1 (Frequency Array Bucketing) Output](../../../../Output-Screenshots/U3-09-01-Counting-Sort-1.png)
